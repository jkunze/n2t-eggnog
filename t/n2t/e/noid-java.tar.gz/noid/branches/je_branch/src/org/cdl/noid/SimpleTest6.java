/*
 * $Id: SimpleTest6.java 149 2006-10-19 02:42:52Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.*;
import java.util.ArrayList;
import java.util.regex.*;
import junit.framework.*;

/** 
 * Equivalent to noid4.t.
 * 
 * @author  Michael Russel
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 149 $
 */
public class SimpleTest6 extends TestCase {

	public SimpleTest6(String name) {
		super(name);
	}
	
	protected void setUp() {
	
	}

	public void testFoo() {
		ArrayList<String> output = new ArrayList<String>();
		TestUtil.checkNoidDir();
		
		TestUtil.execNoid("mint 10");
		TestUtil.execNoid("queue now 13030/tst43m 13030/tst47h 13030/tst44k");
		TestUtil.execNoid("hold set 13030/tst412 13030/tst421");

		TestUtil.execNoid("noid_cmd mint 20", output);

		assertEquals("number of lines in dbnoid/log", 20, output.size());

		if (output.size() != 20) {
			System.err.println("log_lines" + output);
			System.exit(1);
		}

		String[] expected = {
			"id: 13030/tst43m",
			"id: 13030/tst47h",
			"id: 13030/tst44k",
			"id: 13030/tst48t",
			"id: 13030/tst466",
			"id: 13030/tst44x",
			"id: 13030/tst42c",
			"id: 13030/tst49s",
			"id: 13030/tst48f",
			"id: 13030/tst475",
			"id: 13030/tst45v",
			"id: 13030/tst439",
			"id: 13030/tst40q",
			"id: 13030/tst49f",
			"id: 13030/tst484",
			"id: 13030/tst46t",
			"id: 13030/tst45h",
			"id: 13030/tst447",
			"id: 13030/tst42z",
			"id: 13030/tst41n"
		};

		for (int i = 0, j = 1; i < expected.length; i++, j++) {
			assertEquals(
				j + Util.getOrdinalFor(j) + " minted noid failed",
				expected[i],
				(String) output.get(i)
			);
		}
		
	}
}
