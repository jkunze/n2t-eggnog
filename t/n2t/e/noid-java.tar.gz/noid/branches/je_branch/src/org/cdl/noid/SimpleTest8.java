/*
 * $Id: SimpleTest8.java 149 2006-10-19 02:42:52Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import junit.framework.*;

/** 
 * Equivalent to noid6.t.
 * 
 * @author  Michael A. Russel
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 149 $
 */
public class SimpleTest8 extends TestCase {

	public SimpleTest8(String name) {
		super(name);
	}
	
	protected void setUp() {
	
	}

	public void testFoo() {
		ArrayList<String> output = new ArrayList<String>();
		TestUtil.checkNoidDir();
		
		TestUtil.execNoid("mint 1", output);

		String bound = (String) output.get(0);

		assertTrue("\"id: \" preceded minted noid",
			bound.matches("^id:\\s+"));

		bound.replaceFirst("^id:\\s+", "");

		output.clear();

		HashMap<String,String> bindArgs = new HashMap<String,String>();

		ArrayList<String> foo = new ArrayList<String>();

		for (int i = 0; i < 100; i++) {
			String key = TestUtil.genRandomString();
			String val = TestUtil.genRandomString();
			bindArgs.put(key, val);
			foo.add(key + ": " + val);
		}

		Exec exec = new Exec();
		exec.exec("bind set " + bound + " :", foo);

		Util.doExec("./runNoid.sh fetch " + bound, output);

		assertTrue("\"fetch\" command generated some output",
			output.size() > 0);

		if (output.size() == 0) {
			System.err.println("something wrong with fetch, stopped");
			System.exit(1);
		}
		
		String last = (String) output.get(output.size() - 1);
		if (Util.isEmpty(last)) {
			output.remove(last);
		}

		assertEquals("there are 102 lines of output from the \"fetch\" command",
			102, output.size());

		assertTrue("line 1 of \"fetch\" output",
			Util.matches("^id:\\s+ " + bound + "\\s+hold\\s*$",
				(String)output.get(0)));
		assertTrue("line 2 of \"fetch\" output",
			Util.matches("^Circ:\\s+", (String)output.get(1)));


		output.remove(0);
		output.remove(0);

		Pattern patt = Pattern.compile("^\\s*(\\S+)\\s*:\\s*(\\S+)\\s*$");
		Matcher matcher = patt.matcher("");
		for (int i = 0; i < 100; i++) {
			matcher.reset((String) output.get(i));
			if (matcher.find()) {
				String elem  = matcher.group(1);
				String value = matcher.group(2);
			
				if (bindArgs.containsKey(elem))
				{
					if (bindArgs.get(elem).equals(value))
					{
						assertTrue("line " + (i + 3) + " of \"fetch\" output", true);
						bindArgs.remove(elem);
					}
					else
					{
						assertTrue("line "
							+ (i + 3)
							+ " of \"fetch\" "
							+ "output:  element \"" + elem + "\" was "
							+ "bound to value "
							+ "\"" + bindArgs.get(elem) + "\", but "
							+ "\"fetch\" returned that it was "
							+ "bound to value \"" + value + "\"", false);
					}
				}
				else
				{
					assertTrue("line "
				  		+ (i + 3)
				  		+ " of \"fetch\" output "
				  		+ "(\"" + output.get(i) + "\") contained an element "
				  		+ "that was not in the group of elements "
				  		+ "bound to this noid", false);
				}
			}
			else
			{
				assertTrue("line "
					+ (i + 3)
					+ " of \"fetch\" output "
					+ "(\"" + output.get(i) + "\") is in an unexpected format",
					false);
			}
		}
		
// 		Iterator it = bindArgs.entrySet().iterator();
// 		while (it.hasNext()) {
// 			Map.Entry = (Map.Entry) it.next();
// 			String key = (String) entry.getKey();
// 			String value = (String) entry.getValue();
// 		}

		assertEquals("everything that was bound was returned by the \"fetch\" command", 0, bindArgs.size());

	}

}
