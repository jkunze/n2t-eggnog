/*
 * $Id: NoidTest.java 167 2006-10-24 01:24:17Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.*;
import java.util.*;

/**
 * 
 * @author  John Kunze (jak@ucop.edu)
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 167 $
 */
public class NoidTest {


	public static void main(String[] args) {

		String[] command;
		boolean isBulkMode = false;
		NoidCommand nc = new NoidCommand();
		
		// Create system object for doing operations like chmod.
		Sys.SetFactory("org.cdl.noid.UnixSys");
		Sys sys = Sys.GetSys();
		minter.setSys(sys);

		Options opts = sys.getOptions(args);
		boolean debug = opts.getDebug();
		boolean help = opts.getHelp();
		Integer locktest = opts.getLocktest();
		boolean version = opts.getVersion();
		String dbHome = opts.getDbdir();

// 		if (locktest != null) {
// 			int lockval = locktest.intValue();
// 			if (lockval < 0) {
// 				System.out.println("error: locktest value must be a "
// 					+ "positive number of seconds to sleep");
// 				System.exit(0);
// 			}
// 			minter.setLockTest(locktest.intValue());
// 		}
		
		if (version) {
			System.out.print("This is \"noid\" version "
				+ Noid.getVersion());
			System.exit(0);
		}
		
		if (help) {
			usage(false, false, "intro");
			System.exit(0);
		}
		
		if (dbHome == null)
			dbHome = System.getenv("NOID");

		if (dbHome == null)
			dbHome = ".";

		nc.runCommand();
		
		String dbFile = dbHome + "/dbnoid/noid.bdb";
		System.err.println("dbFile = " + dbFile);
		

		boolean isBulkMode = args.length == 1 && args[0].equals("-");

		if (!isBulkMode) {
			nc.runCommand();
			System.exit(0);
		}
		
		String line = null;
		BufferedReader is =
			new BufferedReader(new InputStreamReader(System.in));
		try {
			System.err.println("Reading stdin ...");
			while ((line = is.readLine()) != null) {
				if (line.length() == 0)
					continue;
				StringTokenizer st = new StringTokenizer(line);
				int len = st.countTokens();
				command = new String[len];
				for (int i = 0; i < len; i++) {
					command[i] = st.nextToken();
				}
				nc = new NoidCommand(dbHome, command);
				nc.runCommand();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.exit(0);
	}

}

// vim: set ts=4 nohls:
