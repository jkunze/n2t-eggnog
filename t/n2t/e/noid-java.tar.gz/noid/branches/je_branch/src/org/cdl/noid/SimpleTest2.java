/*
 * $Id: SimpleTest2.java 114 2006-09-15 17:19:39Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.*;
import java.util.regex.*;
import junit.framework.*;

/** 
 * Equivalent to dbcreat.t. 
 * 
 * @author Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 114 $
 */
public class SimpleTest2 extends TestCase {
	
	public SimpleTest2(String name) {
		super(name);
	}
	
	protected void setUp() {
	
	}

	public void testSize() {
		assertTrue("single digit sequential template",
			Util.matches("Size:\\s*10\n", createShort(".sd").getReadme()));
		assertTrue("2-digit sequential template",
			Util.matches("Size:\\s*100\n", createShort(".sdd").getReadme()));
		assertTrue("3-digit unbounded sequential",
			Util.matches("Size:\\s*unlimited\n", createShort(".zded").getReadme()));
		assertTrue("6-digit random template",
			Util.matches("Size:\\s*2438900\n", createShort("fr.reedde").getReadme()));
	}

	public void testTemplates() {
		assertTrue("prefix vowels ok in general",
			Util.matches("Size:\\s*1000\n", createShort("ab.rddd").getReadme()));
		assertTrue("bad mask char",
			Util.matches("parse_template: a mask may contain only the letters",
				createShort("ab.rdxdk").getReadme()));
		assertTrue("prefix vowels not ok with check char",
			Util.matches("a mask may contain only characters from",
				createShort("ab.rdddk").getReadme()));
	}

	public void testTest() {
		Minter minter = createShort("8r9.sdd");
		assertTrue("2-digit sequential",
			Util.matches("Size:\\s*100\n", minter.getReadme()));

		String contact = "Fester Bestertester";
		minter = new Minter(contact, ".");
		minter.dbOpen(null);
		
		String id = "";
		int n;
		
		n = 1;
		while (n-- > 0) {
			id = minter.mint(false);
		}
		assertEquals("sequential mint test first", "8r900", id);

		n = 99;
		while (n-- > 0) {
			id = minter.mint(false);
		}
		assertEquals("sequential mint test last", "8r999", id);

		n = 1;
		while (n-- > 0) {
			id = minter.mint(false);
		}
		assertEquals("sequential mint test wrap to first", "8r900", id);

		minter.close();
	}


	private static Minter createShort (String templ) {
		File noidDir = new File("dbnoid");

		if (noidDir.isDirectory()) {
			if (!Util.deleteDir(noidDir)) {
				System.err.println("can't delete dbnoid directory");
				System.exit(1);
			}
		}

		String term = "short";
		String naan = null;
		String naa = null;
		String subnaa = null;

		Minter minter = new Minter();
		minter.setContact("rasan");
		minter.setDbHome(".");
		
		minter.dbCreate(templ, term, naan, naa, subnaa);
		
		return minter;
	}
	
}
