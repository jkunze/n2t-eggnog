/*
 * $Id: UnixSys.java 148 2006-10-18 21:53:33Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import jargs.gnu.CmdLineParser;
import java.io.IOException;

/** 
 * UnixSys is a class for file system operations on a Unix-flavored
 * operating system.  It is a concrete class of the Sys abstract
 * class.
 * 
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 148 $
 */
public class UnixSys extends Sys {

	/** 
	 * Construct a new UnixSys object.
	 */
	public UnixSys() {
		super();
	}

	/** 
	 * Return <code>CmdLineOptions</code> object representing the
	 * parsed command line options for <code>NoidTest<code>.
	 * 
	 * @param  args command line arguments
	 * @return      Options
	 * @see         Options
	 */
	public Options getOptions(String[] args) {
		CmdLineOptions opts = new CmdLineOptions(args);
		opts.parseOptions();
		return opts;
	}

	/** 
	 * Return string representing user for current process.
	 * 
	 * @param  isWeb is current process in web context
	 * @return       user string
	 */
	public String getUser(boolean isWeb) {
	
		String user = null;

		if (isWeb) {
			user = System.getenv("REMOTE_USER");
			String host = System.getenv("REMOTE_HOST");
			if (host == null)
				host = System.getenv("REMOTE_ADDR");
			user += '@' + host;
		}
		
		return user;
	
	}

	/** 
	 * Set permissions for a file.
	 * 
	 * @param fileName input file whose mode will be changed
	 * @return         <code>true</code> if operation was successful;
	 *                 <code>false</code> otherwise
	 */
	public boolean chmod(String fileName) {
		return Util.doExec("chmod 0600 " + fileName);
	}

	/** 
	 * Print system information to stdout.
	 */
	public static void printSystemInfo() {
		try {
			System.getProperties().store(System.out, "System Properties:");
		} catch (IOException e) {
			e.printStackTrace();
		}
    }

}
