/*
 * $Id: SimpleTest9.java 149 2006-10-19 02:42:52Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.*;
import java.util.ArrayList;
import java.util.regex.*;
import junit.framework.*;

/** 
 * Equivalent to noid7.t
 * 
 * @author  Michael A. Russel
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 149 $
 */
public class SimpleTest9 extends TestCase {

	public SimpleTest9(String name) {
		super(name);
	}
	
	protected void setUp() {
	
	}

	public void testFoo() {
		ArrayList<String> output = new ArrayList<String>();
		TestUtil.checkNoidDir();
		
		TestUtil.execNoid("mint 2", output);

		String last = (String) output.get(output.size() - 1);
		if (Util.isEmpty(last)) {
			output.remove(last);
		}

		String bound1 = (String) output.get(0);
		String bound2 = (String) output.get(1);

		assertTrue("first line:  \"id: \" preceded minted noid",
			bound1.matches("^id:\\s+"));
		assertTrue("second line:  \"id: \" preceded minted noid",
			bound2.matches("^id:\\s+"));

		bound1 = bound1.replaceFirst("^id:\\s+", "");
		bound2 = bound2.replaceFirst("^id:\\s+", "");

		output.clear();

		String elem1 = TestUtil.genRandomString();
		String value1 = TestUtil.genRandomString();

		ArrayList<String> input = new ArrayList<String>();
		input.add(elem1 + ": " + value1);
		Exec exec = new Exec();
		exec.exec("bind set " + bound1 + " :- >/dev/null", input);

		String elem2 = "";
		while (elem2.length() < 1500) {
			elem2 += TestUtil.genRandomString();
		}

		ArrayList<String> value2 = new ArrayList<String>();
		for (int i = 0; i < 10; i++) {
			value2.add(TestUtil.genRandomString());
		}

		input.clear();
		for (int i = 0; i < value2.size(); i++) {
			input.add(value2.get(i));
		}
		input.set(0, elem2 + ": " + input.get(0));

		exec = new Exec();
		exec.exec("bind set " + bound2 + " :- >/dev/null", input);

		Util.doExec("./runNoid.sh fetch " + bound1, output);

		assertTrue("\"fetch\" command on noid 1 generated some output",
			output.size() > 0);

		if (output.size() == 0) {
			System.err.println("something wrong with fetch, stopped");
			System.exit(1);
		}

		int size = output.size();
		last = (String) output.get(size - 1);
		while (size > 0 && Util.isEmpty(last)) {
			output.remove(size - 1);
			size = output.size();
		}
		
		assertEquals("there are 3 lines of output from the \"fetch\" command on noid 1",
			3, output.size());

		if (output.size() != 3) {
			System.err.println("something wrong with fetch output, stopped");
			System.exit(1);
		}

		assertTrue("line 1 of \"fetch\" output for noid 1",
			Util.matches("^id:\\s+" + bound1 + "\\s+hold\\s*$",
				(String)output.get(0)));
		assertTrue("line 2 of \"fetch\" output for noid 1",
			Util.matches("^Circ:\\s+", (String)output.get(1)));

		Pattern patt = Pattern.compile("^\\s*(\\S+)\\s*:\\s*(\\S+)\\s*$");
		Matcher matcher = patt.matcher((String)output.get(2));
		if (!matcher.find()) {
			assertTrue("line 3 of \"fetch\" output for noid 1", false);
			System.err.println("something wrong with bound value, stopped");
			System.exit(1);
		}

		assertTrue("line 3 of \"fetch\" output for noid 1",
			elem1.equals(matcher.group(1)) && value1.equals(matcher.group(2)));

		Util.doExec("./runNoid.sh fetch " + bound2, output);

		assertTrue("\"fetch\" command on noid 2 generated some output",
			output.size() > 0);
		if (output.size() == 0) {
			System.err.println("something wrong with fetched value, stopped");
			System.exit(1);
		}

		size = output.size();
		last = (String) output.get(size - 1);
		while (size > 0 && Util.isEmpty(last)) {
			output.remove(size - 1);
			size = output.size();
		}

		assertEquals("there are 12 lines of output from the \"fetch\" command on noid 2",
			12, output.size());


		assertTrue("line 1 of \"fetch\" output for noid 2",
			Util.matches("^id:\\s+" + bound2 + "\\s+hold\\s*$",
				(String)output.get(0)));
		assertTrue("line 2 of \"fetch\" output for noid 2",
			Util.matches("^Circ:\\s+", (String)output.get(1)));

		patt = Pattern.compile("^\\s*(\\S+)\\s*:\\s*(\\S+)\\s*$");
		matcher = patt.matcher((String)output.get(2));
		if (!matcher.find()) {
			assertTrue("line 3 of \"fetch\" output for noid 2", false);
			System.err.println("something wrong with bound value, stopped");
			System.exit(1);
		}
		
		assertTrue("line 3 of \"fetch\" output for noid 2",
			elem2.equals(matcher.group(1)) &&
				((String) value2.get(0)).equals(matcher.group(2)));

		for (int i = 1; i <= 9; i++) {
			assertEquals("line " + (i + 3) + " of \"fetch\" output for noid 2",
				output.get(i + 2), (String) value2.get(i));
		}

	}

}
