/*
 * $Id: SimpleTest10.java 142 2006-09-26 03:28:28Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.*;
import java.util.ArrayList;
import java.util.regex.*;
import java.util.StringTokenizer;
import junit.framework.*;

/** 
 * Equivalent to noid8.t
 * 
 * @author  Michael A. Russel
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 142 $
 */
public class SimpleTest10 extends TestCase {

	public SimpleTest10(String name) {
		super(name);
	}
	
	protected void setUp() {
	
	}

	public void testFoo() {
		
		system("dbcreate .rde long 13030 cdlib.org noidTest");
		system("dbcreate .rddk long 13030 cdlib.org noidTest");
		checkPolicy("GRANITE");

		system("dbcreate .rddk long 00000 cdlib.org noidTest");
		checkPolicy("-RANITE");

		system("dbcreate .sddk long 13030 cdlib.org noidTest");
		checkPolicy("G-ANITE");

		system("dbcreate tst8.rdek long 13030 cdlib.org noidTest");
		checkPolicy("GR-NITE");

		system("dbcreate .rddk medium 13030 cdlib.org noidTest");
		checkPolicy("GRA-ITE");

		system("dbcreate r-r.rdd long 13030 cdlib.org noidTest");
		checkPolicy("GRAN--E");

		system("dbcreate .rdd long 13030 cdlib.org noidTest");
		checkPolicy("GRANI-E");

		system("dbcreate a.rdd long 13030 cdlib.org noidTest");
		checkPolicy("GRANI--");

		system("dbcreate a-a.seeeeee medium 00000 cdlib.org noidTest");
		checkPolicy("-------");
	}

	public void system(String command) {
		File noidDir = new File("NOID");
		Util.deleteDir(noidDir);
		if (noidDir.exists()) {
			if (!Util.deleteDir(noidDir)) {
				System.err.println("Unable to delete dbnoid");
			}
		}
		Util.doExec(command);
	}

	public void checkPolicy(String expected) {
		String policy = getPolicy("README");
		if (policy != null) {
			assertEquals("policy \"" + expected + "\"", expected, policy);
		} else {
			assertTrue("unable to get policy", false);
		}
	}

	public String getPolicy(String file) {
		String contents = Util.getFile(file);
		StringTokenizer st = new StringTokenizer(contents);
		String regexp = "^Policy:\\s+\\(:((G|-)(R|-)(A|-)"
			+ "(N|-)(I|-)(T|-)(E|-))\\)\\s*$";
		Pattern patt = Pattern.compile(regexp);

		Matcher matcher = patt.matcher("");
		while (st.hasMoreTokens()) {
			matcher.reset(st.nextToken());
			if (matcher.find()) {
				return matcher.group(1);
			}
		}
		return null;
	}

}
