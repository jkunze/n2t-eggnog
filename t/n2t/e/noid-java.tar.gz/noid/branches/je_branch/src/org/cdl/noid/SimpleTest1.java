/*
 * $Id: SimpleTest1.java 142 2006-09-26 03:28:28Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.*;
import java.util.regex.*;
import junit.framework.*;

/** 
 * Equivalent to bind.t.
 * 
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 142 $
 */
public class SimpleTest1 extends TestCase {

	public SimpleTest1(String name) {
		super(name);
	}
	
	protected void setUp() {
	
	}

	public void testBind() {
		Minter minter;
		String contact;
		String id;
		String[] elem = new String[1];
		String result;

		minter = createShort(".sdd");
		assertTrue("2-digit sequential failed",
			Util.matches("Size:\\s*100\n", minter.getReadme()));

		contact = "Fester Bestertester";
		minter.setContact(contact);

		id = minter.mint(false);
		id = minter.mint(false);
		assertEquals("sequential mint verify failed", "01", id);

		result = minter.bind(true, "set", id, "myelem", "myvalue");
		assertTrue("simple bind failed",
			Util.matches("Status:  ok, 7", result));

		elem[0] = "myelem";
		result = minter.fetch(true, id, elem);
		assertTrue("simple fetch failed",
			Util.matches("myelem: myvalue", result));

		result = minter.fetch(false, id, elem);
		assertEquals("simple non-verbose (get) fetch failed",
			"myvalue", result);

		minter.close();
	}

	public void testQueue() {
		Minter minter;
		Noid noid;
		String contact;
		String id;
		String[] elem = new String[1];
		int result;
		String[] results;

		minter = createShort(".sdd");
		assertTrue("2-digit sequential failed",
			Util.matches("Size:\\s*100\n", minter.getReadme()));
		//minter.close();

		contact = "Fester Bestertester";
		minter = new Minter(contact, ".");
		noid = minter.dbOpen(null);

		id = minter.mint(false);
		assertEquals("mint first failed", "00", id);

		boolean success = minter.hold("set", "01");
		assertTrue("hold next failed", success);

		id = minter.mint(false);
		assertEquals("mint next skips id held failed", "02", id);

		// Shouldn't have to release hold to queue it
		results = minter.queue("now", id);
		assertEquals("queue previously held", "id: " + id, results[0]);

		id = minter.mint(false);
		assertEquals("mint next gets from queue failed", "02", id);
		
		id = minter.mint(false);
		assertEquals("mint next back to normal", "03", id);

		minter.close();
	}

	public void testValidate() {
		Minter minter;
		Noid noid;
		String contact;
		String id;
		String[] elem = new String[1];
		String[] results;

		minter = createShort("fk.redek");
		assertTrue("4-digit random failed",
			Util.matches("Size:\\s*8410\n", minter.getReadme()));
		minter.close();

		contact = "Fester Bestertester";
		minter = new Minter(contact, ".");
		noid = minter.dbOpen(null);

		id = minter.mint(false);
		assertEquals("mint one failed", "fk491f", id);

		results = minter.validate("-", "fk491f");
		assertFalse("validate just minted failed",
			Util.grep2("error: ", results));

		results = minter.validate("-", "fk492f");
		assertTrue("detect one digit off failed",
			Util.grep2("iderr: ", results));

		results = minter.validate("-", "fk419f");
		assertTrue("detect transposition failed",
			Util.grep2("iderr: ", results));

		minter.close();
	}

	private static Minter createShort (String templ) {
		File noidDir = new File("dbnoid");

		if (noidDir.isDirectory()) {
			if (!Util.deleteDir(noidDir)) {
				System.err.println("can't delete dbnoid directory");
				System.exit(1);
			}
		}

		String term = "short";
		String naan = null;
		String naa = null;
		String subnaa = null;

		Minter minter = new Minter();
		minter.setContact("rasan");
		minter.setDbHome(".");
		
		minter.dbCreate(templ, term, naan, naa, subnaa);
		
		return minter;
	}

}
