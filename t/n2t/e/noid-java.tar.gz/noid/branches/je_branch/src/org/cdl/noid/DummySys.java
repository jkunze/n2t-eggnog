/*
 * $Id: DummySys.java 114 2006-09-15 17:19:39Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

/** 
 * DummSys is a class that does no-op's when asked to do file system
 * operations.  It is a concrete class of the Sys abstract class.
 * It's meant to be used on operating systems that cannot perform
 * any operations like chmod or getuid.
 * 
 * @author  Rasan Rasch (rasan@nyu.edu)
 * @version $Revision
 */
public class DummySys extends Sys {
	
	/** 
	 * Constructs a new DummySys object. 
	 */
	public DummySys() {
		super();
	}

	/** 
	 * Returns -1 (Operation not implemented).
	 */
	public int getUserID() {
		return -1;
	}

	/** 
	 * Returns -1 (Operation not implemented).
	 */
	public int getGroupID() {
		return -1;
	}

	/** 
	 * Return empty <code>DummyOptions</code>.  Don't parse
	 * any command line options.
	 * @see         DummyOptions
	 */
	public Options getOptions(String[] args) {
		return new DummyOptions(args);
	}

	/** 
	 * Always Return true (Operation not implemented).
	 */
	public boolean chmod(String fileName) {
		return true;
	}
	
	/** 
	 * Return string representing user for program.
	 * 
	 * @param  isWeb is current program in web context
	 * @return       user string
	 */
	public String getUser(boolean isWeb) {
		return System.getProperty("user.name");
	}

}
