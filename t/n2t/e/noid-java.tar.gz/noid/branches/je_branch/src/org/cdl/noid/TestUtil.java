/*
 * $Id: TestUtil.java 149 2006-10-19 02:42:52Z rasan $
 *
 * Copyright (c) 2002-2006 UC Regents
 * 
 * Permission to use, copy, modify, distribute, and sell this software and
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names
 * of the UC Regents and the University of California are not used in any
 * advertising or publicity relating to the software without the specific,
 * prior written permission of the University of California.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE FOR ANY
 * SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY
 * THEORY OF LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOFTWARE.
 */

package org.cdl.noid;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import junit.framework.Assert;

/** 
 * TestUtil contains common routines shared by many of our JUnit
 * test classes.
 * 
 * @author Rasan Rasch (rasan@nyu.edu)
 * @version $Revision: 149 $
 */
public class TestUtil {

	public static void checkNoidDir() {
		String command = "$noid_cmd dbcreate tst4.rde long 13030 cdlib.org noidTest";
		checkNoidDir(command);
	}

	/** 
	 * Create a minter database and check that all the appropriate
	 * minter files were successfully created.
	 * 
	 * @param command 
	 */
	public static void checkNoidDir(String command) {

		File noidDir = new File("dbnoid");
		
		Util.deleteDir(noidDir);

		if (noidDir.exists()) {
			if (!Util.deleteDir(noidDir)) {
				System.err.println("Unable to delete dbnoid");
			}
		}

		Util.doExec(command);
		
		Assert.assertTrue("dbnoid was created failed", noidDir.isDirectory());

		if (!noidDir.isDirectory()) {
			System.err.println("something is seriously wrong, stopped");
			System.exit(1);
		}

		String[] files = { "README", "log", "logbdb", "noid.bdb" };
		for (int i = 0; i < files.length; i++) {
			File f = new File("dbnoid/" + files[i]);
			Assert.assertTrue("dbnoid/" + files[i] + " was not created", f.exists());
		}

		if (!(new File("dbnoid/noid.bdb")).exists()) {
			System.err.println("something is seriously wrong, stopped");
			System.exit(1);
		}

		ArrayList<String> output = new ArrayList<String>();
	
	}

	public static void execNoid(String args) {
		String command = "java NoidTest" + args;
		Util.doExec(command);
	}

	public static void execNoid(String args, ArrayList<String> out) {
		String command = "java NoidTest " + args;
		Util.doExec(command, out);
	}

	/** 
	 * Generate a random string.  The length of this string will
	 * be between 3 and 50.  The alphabet used to build it will
	 * be the upper and lower case letters of the English alphabet
	 * plus digits 0-9.
	 * 
	 * @return random string
	 */
	public static String genRandomString() {
		String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
			+ "abcdefghijklmnopqrstuvwxyz"
			+ "0123456789";

		int alphaLen = alpha.length();

		// Generate a random string length between 3 and 50.
		Random generator = new Random();
		int len = generator.nextInt(48) + 3;

		StringBuffer sb = new StringBuffer(len);

		for (int i = 0; i < len; i++) {
			sb.append(alpha.charAt(generator.nextInt(alphaLen)));
		}

		return sb.toString();
	}

}

