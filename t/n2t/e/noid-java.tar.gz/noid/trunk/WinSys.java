public class WinSys extends Sys {

	public WinSys() {
		super();
	}

	public int getUserID() {
		return -1;
	}

	public int getGroupID() {
		return -1;
	}

	public Options getOptions() {

	}

}
