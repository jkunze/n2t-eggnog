
public class DummyOptions implements Options {
	
	public DummyOptions(String[] args) {
	}

	public void parseOptions() {
	}

	public boolean getDebug() {
		return false;
	}

	public boolean getHelp() {
		return false;
	}

	public boolean getVersion() {
		return false;
	}
	
	public int getLocktest() {
		return -1;
	}
	
	public String getDbdir() {
		return null;
	}

}
