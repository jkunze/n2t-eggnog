import java.io.*;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.regex.*;
import java.text.DecimalFormat;

class Util {

	public static String valueOrEmpty(String str) {
		return str != null ? str : "";
	}
	
	public static boolean isEmpty(String s) {
		return s == null || s.length() == 0;
	}

	public static boolean isEmpty(Object[] array) {
		return array == null || array.length == 0;
	}

	public static String join(String delim, String[] args) { 
		StringBuffer result = new StringBuffer();
		int len = args.length;
		for (int i = 0; i < len; i++) { 
			result.append(args[i]);
			if (i < len - 1) {
				result.append(delim);
			}
		} 
		return result.toString();
	}

	public static String[] grep(String regexp, String[] args) {
		ArrayList list = new ArrayList();
		Pattern patt = Pattern.compile(regexp);
		Matcher matcher = patt.matcher("");
		for (int i = 0; i < args.length; i++) {
			matcher.reset(args[i]);
			if (matcher.find()) {
				list.add(args[i]);
			}
		}
		String[] matches = (String[])list.toArray(new String[0]);
		return matches;
	}

	public static boolean grep2(String regexp, String[] args) {
		Pattern patt = Pattern.compile(regexp);
		Matcher matcher = patt.matcher("");
		for (int i = 0; i < args.length; i++) {
			matcher.reset(args[i]);
			if (matcher.find()) {
				return true;
			}
		}
		return false;
	}

	public static String getHostName () {
		String hostName = null;
		try {
			InetAddress localMachine = InetAddress.getLocalHost(); 
			hostName = localMachine.getHostName();
		} catch (java.net.UnknownHostException uhe) {
            // handle exception
		}
		return hostName;
	}
	
	public static Object shift(ArrayList list) {
		return list.size() > 0 ? list.remove(0) : null;
	}

	public static String getCwd() {
		String cwd = null;
		try {
			cwd = new File(".").getCanonicalPath();
		} catch (IOException e) {
			// handle exception
		}
		return cwd;
	}

	public static String getFile(String fileName) {
		StringBuffer sb = new StringBuffer();
		try {
			BufferedReader in =
				new BufferedReader(new FileReader(fileName));
			String str;
			while ((str = in.readLine()) != null) {
				sb.append(str);
			}
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	
	public static boolean matches(String pattern, String input) {
		return Pattern.compile(pattern).matcher(input).find();
	}

	public static String zeroPad(int value, int length) {
		// DecimalFormat df = new DecimalFormat("00");
		DecimalFormat df = new DecimalFormat();
		df.setMinimumIntegerDigits(length);
		// df.setGroupingUsed(false);
		return df.format(value);
	}

	public static void setBuffer(StringBuffer sb, String newValue) {
		sb.setLength(0);
		sb.append(newValue);
	}

	// XXX: Put this in Util.java
	// Deletes all files and subdirectories under dir.
	// Returns true if all deletions were successful.
	// If a deletion fails, the method stops attempting
	// to delete and returns false.
	public static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i=0; i<children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}
	
		// The directory is now empty so delete it
		return dir.delete();
	}

	// Used by unit tests
	private static Minter createShort (String templ) {
		File noidDir = new File("NOID");

		if (noidDir.isDirectory()) {
			if (!deleteDir(noidDir)) {
				System.err.println("can't delete NOID directory");
				System.exit(1);
			}
		}

		String term = "short";
		String naan = null;
		String naa = null;
		String subnaa = null;

		Minter minter = new Minter();
		minter.setContact("rasan");
		minter.setDbHome(".");
		
		minter.dbCreate(templ, term, naan, naa, subnaa);
		
		return minter;
	}

	public static boolean doExec(String command) {
		boolean success = false;
		try {
			Process child = Runtime.getRuntime().exec(command);
			success = child.exitValue() == 0;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return success;
	}

	public static boolean doExec(String command, ArrayList list) {
		boolean success = false;
		list.clear();
		try {
			// Execute command
			Process child = Runtime.getRuntime().exec(command);
		
			// Get the input stream and read from it
			BufferedReader in = new BufferedReader(
				new InputStreamReader(child.getInputStream()));
			String str;
			while ((str = in.readLine()) != null) {
				list.add(str);
			}
			in.close();

			success = child.exitValue() == 0;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return success;
	}
	
}
