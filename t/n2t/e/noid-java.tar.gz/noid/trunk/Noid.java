import java.io.*;
import java.util.*;
import com.sleepycat.db.*;

public class Noid {

	private String id = "";

	private String msg = "";

	private Database db = null;

	private PrintStream log = null;

	private static String R = ":";

	private Map map = new HashMap();

	// Our constructor does nothing
	public Noid() {
	}

	public Noid(String adminPrefix) {
// 		R = adminPrefix;
	}

	public Database getDB() {
		return db;
	}

	public void setDB(Database database) {
		db = database;
	}

	public String getMsg() {
		return msg;
	}

	public String getMsg(boolean reset) {
		String buf = msg;
		if (reset) {
			msg = "";
		}
		return buf;
	}

	public void setMsg(String buf) {
		msg = buf;
	}

	public void addMsg(String buf) {
		System.err.println(buf);
		msg += buf + "\n";
	}

	public void setLog(PrintStream out) {
		log = out;
	}

	public void writeLog(String buf) {
		log.println(buf);
	}

	// Close the databases
	public void close() {
		try {
			if (db != null) {
				db.close();
			}
		} catch (DatabaseException dbe) {
			System.err.println("Error closing db: " + dbe.toString());
			System.exit(-1);
		}
	}

	public String get(String key) {
		String foundData = null;
		try {
			// Create a pair of DatabaseEntry objects. theKey
			// is used to perform the search. theData is used
			// to store the data returned by the get() operation.
			DatabaseEntry theKey = new DatabaseEntry(key.getBytes("UTF-8"));
			DatabaseEntry theData = new DatabaseEntry();
			
			// Perform the get.
			if (db.get(null, theKey, theData, LockMode.DEFAULT) ==
					OperationStatus.SUCCESS) {
		
				// Recreate the data String.
				byte[] retData = theData.getData();
				foundData = new String(retData);
				System.out.println("For key: '" + key + "' found data: '" + 
									foundData + "'.");
			} else {
				System.out.println("No record found for key '" + key + "'.");
			} 
		} catch (Exception e) {
			// Exception handling goes here
		}
		return foundData;
	}

	public String rGet(String key) {
		return get(R + "/" + key);
	}

	public int rGetInt(String key) {
		return Integer.parseInt(rGet(key));
	}

	public boolean rGetBool(String key) {
		String str = rGet(key);
		if (str.equals("0")) {
			return false;
		}
		str = str.toLowerCase();
		if (str.equals("false")) {
			return false;
		}
		if (str.equals("no")) {
			return false;
		}
		// if it's non false, it's true by definition
		return true;
	}

	public boolean set(String key, String value) {
		DatabaseEntry theKey, theValue;
		OperationStatus status = null;
		try {
			theKey = new DatabaseEntry(key.getBytes("UTF-8"));
			theValue = new DatabaseEntry(value.getBytes("UTF-8"));
			status = db.put(null, theKey, theValue);
		} catch (Exception e) {
			// Exception handling goes here
		}
		if (status == OperationStatus.SUCCESS) {
			System.err.println("Successfully wrote " + key);
			return true;
		} else {
			System.err.println("Failed to write " + key);
			return false;
		}
	}

	public boolean set(String key, boolean value) {
		String s = value ? "true" : "false";
		return set(key, s);
	}

	public boolean set(String key, int value) {
		return set(key, Integer.toString(value));
	}

	public boolean rSet(String key, String value) {
		return set(R + "/" + key, value);
	}

	public boolean rSet(String key, int value) {
		return set(R + "/" + key, value);
	}

	public boolean rSet(String key, boolean value) {
		return set(R + "/" + key, value);
	}

	public boolean append(String key, String buf) {
		String value = get(key);
		if (value == null)
			value = "";
		value += buf;
		return set(key, value);
	}

	public boolean prepend(String key, String buf) {
		String value = get(key);
		if (value == null)
			value = "";
		value = buf + value;
		return set(key, value);
	}

	public boolean rInc(String key) {
		return rSet(key, Integer.toString(rGetInt(key) + 1));
	}

	public boolean rDec(String key) {
		return rSet(key, Integer.toString(rGetInt(key) - 1));
	}

	public boolean defined(String key) {
		return map.containsKey(key) && map.get(key) != null;
	}

	public boolean exists(String key) {
		return map.containsKey(key);
	}

	public boolean isEmpty(String key) {
		String value;
		if (!exists(key))
			return true;
		value = get(key);
		return value == null || value.length() == 0;
	}

	public boolean rDefined(String key) {
		return defined(R + "/" + key);
	}

	public void remove(String key) {
		map.remove(key);
	}

}

/* vim: set ts=4 ai nowrap: */

