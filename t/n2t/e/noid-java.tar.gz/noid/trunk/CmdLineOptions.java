import jargs.gnu.CmdLineParser;
import jargs.gnu.CmdLineParser.Option;

public class CmdLineOptions implements Options {
	
	String[] args;
	CmdLineParser parser;
	
	Boolean debug;
	Boolean help;
	Boolean version;
	Integer locktest;
	String dbdir;

	public CmdLineOptions(String[] args) {
		this.args = args;
		this.parser = new CmdLineParser();
	}

	public void parseOptions() {
		
		Option debugOpt    = parser.addBooleanOption("debug");
		Option locktestOpt = parser.addIntegerOption("locktest");
		Option dbdirOpt    = parser.addStringOption("dbdir");
		Option versionOpt  = parser.addBooleanOption("version");
		Option helpOpt     = parser.addBooleanOption("help"); 

		try {
			parser.parse(args);
		} catch (CmdLineParser.OptionException e) {
			System.exit(2);
		}

		debug    = (Boolean) parser.getOptionValue(debugOpt, Boolean.FALSE);
		help     = (Boolean) parser.getOptionValue(helpOpt, Boolean.FALSE);
		version  = (Boolean) parser.getOptionValue(versionOpt, Boolean.FALSE);
		locktest = (Integer) parser.getOptionValue(locktestOpt);
		dbdir    = (String) parser.getOptionValue(dbdirOpt);

	}

	public boolean getDebug() {
		return debug.booleanValue();
	}

	public boolean getHelp() {
		return help.booleanValue();
	}

	public boolean getVersion() {
		return version.booleanValue();
	}
	
	public Integer getLocktest() {
		return locktest;
	}
	
	public String getDbdir() {
		return dbdir;
	}

}
