import jargs.gnu.CmdLineParser;
import javaunix.*;

public class UnixSys
  extends Posix
{
	public
	UnixSys()
	{  super();  }

	public int
	getUserID()
	{  throw new NoSuchFeatureException( "No UserID" );  }

	public int
	getGroupID()
	{  throw new NoSuchFeatureException( "No GroupID" );  }

}
