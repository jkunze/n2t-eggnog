#!/bin/sh
#
# $Id: build-noid.sh 58 2006-05-12 23:23:05Z rasan $
#
# Script to build nightly snapshot of noid.  This will
# be run from a crontab.

set -e
#set -x

NAME=noid

# Location of noid subversion repository
REPOS="https://raschr01.acs.its.nyu.edu/repos/cdl/$NAME/trunk"

umask 077

tmpdir=${TMPDIR-/tmp}/$NAME-build.$$
mkdir $tmpdir || exit 1
trap "rm -rf $tmpdir; exit" 0 1 2 3 15

DATE=`date +%Y%m%d`

BUILD_DIR="$NAME-$DATE"

TARFILE="$NAME-$DATE.tar.bz2"

cd $tmpdir
svn -q checkout $REPOS $BUILD_DIR
find . -name .svn | xargs rm -rf
tar jcf $TARFILE $NAME-$DATE
install -m 0644 $TARFILE /var/www/noid

