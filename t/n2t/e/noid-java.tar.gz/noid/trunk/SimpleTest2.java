import java.io.*;
import java.util.regex.*;
import junit.framework.*;

public class SimpleTest2 extends TestCase {
	
	public SimpleTest2(String name) {
		super(name);
	}
	
	protected void setUp() {
	
	}

	public void testSize() {
		assertTrue("single digit sequential template",
			Util.matches("Size:\\s*10\n", createShort(".sd").getReadme()));
		assertTrue("2-digit sequential template",
			Util.matches("Size:\\s*100\n", createShort(".sdd").getReadme()));
		assertTrue("3-digit unbounded sequential",
			Util.matches("Size:\\s*unlimited\n", createShort(".zded").getReadme()));
		assertTrue("6-digit random template",
			Util.matches("Size:\\s*2438900\n", createShort("fr.reedde").getReadme()));
	}

	public void testTemplates() {
		assertTrue("prefix vowels ok in general",
			Util.matches("Size:\\s*1000\n", createShort("ab.rddd").getReadme()));
		assertTrue("bad mask char",
			Util.matches("parse_template: a mask may contain only the letters",
				createShort("ab.rdxdk").getReadme()));
		assertTrue("prefix vowels not ok with check char",
			Util.matches("a mask may contain only characters from",
				createShort("ab.rdddk").getReadme()));
	}

	public void testTest() {
		Minter minter = createShort("8r9.sdd");
		assertTrue("2-digit sequential",
			Util.matches("Size:\\s*100\n", minter.getReadme()));

		String contact = "Fester Bestertester";
		minter = new Minter(contact, ".");
		minter.dbOpen(null);
		
		String id = "";
		int n;
		
		n = 1;
		while (n-- > 0) {
			id = minter.mint(false);
		}
		assertEquals("sequential mint test first", "8r900", id);

		n = 99;
		while (n-- > 0) {
			id = minter.mint(false);
		}
		assertEquals("sequential mint test last", "8r999", id);

		n = 1;
		while (n-- > 0) {
			id = minter.mint(false);
		}
		assertEquals("sequential mint test wrap to first", "8r900", id);

		minter.close();
	}


	private static Minter createShort (String templ) {
		File noidDir = new File("NOID");

		if (noidDir.isDirectory()) {
			if (!Util.deleteDir(noidDir)) {
				System.err.println("can't delete NOID directory");
				System.exit(1);
			}
		}

		String term = "short";
		String naan = null;
		String naa = null;
		String subnaa = null;

		Minter minter = new Minter();
		minter.setContact("rasan");
		minter.setDbHome(".");
		
		minter.dbCreate(templ, term, naan, naa, subnaa);
		
		return minter;
	}
	
}
