/**
 * @version $Id: Sys.java 15 2006-04-06 03:54:37Z rasan $
 */

abstract public class Sys {

	private static Class factoryClass = null;

	private static Sys theSys = null;

	private static String[] args = null;

	public static synchronized Sys GetSys() throws IllegalArgumentException {
		if (theSys != null)
			return (theSys);

		String reason = "Unknown error";

		try {
			return (theSys = (Sys) factoryClass.newInstance());
		} catch (NullPointerException why) {
			reason = "Null factory: ";
		} catch (ClassCastException why) {
			reason = "Wrong class type: ";
		} catch (InstantiationException why) {
			reason = "Instantiation exception: ";
		} catch (IllegalAccessException why) {
			reason = "Illegal access: ";
		}

		theSys = null;

		throw new IllegalArgumentException(reason
				+ String.valueOf(factoryClass));
	}

	public static synchronized void SetFactory(String className)
			throws IllegalArgumentException {
		theSys = null;

		if (className == null) {
			factoryClass = null;
			return;
		}

		String reason = "Unknown error";
		try {
			factoryClass = Class.forName(className);
			GetSys();
			return;
		} catch (ClassNotFoundException why) {
			reason = "Class not found: ";
		} catch (Throwable why) {
			reason = why.getMessage();
		}

		factoryClass = null;
		throw new IllegalArgumentException(reason + String.valueOf(className));
	}

	public static synchronized Class GetFactory() {
		return (factoryClass);
	}

	protected Sys() {
		super();
	}

	abstract public Options getOptions(String[] args);
	
	abstract public String getUser(boolean isWeb);

	abstract public boolean chmod(String fileName);

	public void printSysinfo() {
		System.err.println("OS Name: " + System.getProperty("os.name"));
		System.err.println("OS Architecture: " + System.getProperty("os.arch"));
		System.err.println("OS Version: " + System.getProperty("os.version"));
	}
}
