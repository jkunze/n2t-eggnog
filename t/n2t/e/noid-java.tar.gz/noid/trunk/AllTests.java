import junit.framework.TestSuite;

public class AllTests {
    public static TestSuite suite() {
        TestSuite s = new TestSuite();
        s.addTestSuite(SimpleTest1.class);
        s.addTestSuite(SimpleTest2.class);
        s.addTestSuite(SimpleTest3.class);
		s.addTestSuite(SimpleTest4.class);
        return s;
    }
}
