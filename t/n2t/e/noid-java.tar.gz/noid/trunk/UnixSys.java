import jargs.gnu.CmdLineParser;
import javaunix.*;
import javaunix.io.*;
import java.io.IOException;

public class UnixSys extends Sys {

	public UnixSys() {
		super();
	}

	public Options getOptions(String[] args) {
		CmdLineOptions opts = new CmdLineOptions(args);
		opts.parseOptions();
		return opts;
	}

	public String getUser(boolean isWeb) {
	
		String user = null;

		if (isWeb) {
			user = System.getenv("REMOTE_USER");
			String host = System.getenv("REMOTE_HOST");
			if (host == null)
				host = System.getenv("REMOTE_ADDR");
			user += '@' + host;
		}
		
		try {
			int uid = UnixSystem.getUid();
			int gid = UnixSystem.getGid();
			int effectiveUid = UnixSystem.getEffectiveUid();
			int effectiveGid = UnixSystem.getEffectiveGid();
	
			Password passwd = UnixSystem.getPasswordByUid(uid);
			Group group = UnixSystem.getGroupByGid(gid);
		
			String userName = System.getProperty("user.name");
			if (userName == null)
				userName = passwd.getName();
			if (userName == null)
				return "";
		
			String groupName = group.getName();
			user = userName + "/" + Util.valueOrEmpty(groupName);

			if (uid != effectiveUid) {
				passwd = UnixSystem.getPasswordByUid(uid);
				group = UnixSystem.getGroupByGid(gid);
				userName = passwd.getName();
				if (userName == null)
					return "";
				groupName = group.getName();
				user += " (" + userName + "/"
					+ Util.valueOrEmpty(groupName) + ")";
			}
		} catch (Exception e) {
			System.err.println(e);
		}

		return user;
	
	}

// 	public boolean chmod(String fileName) {
// 		boolean success = false;
// 		try {
// 			Process p = Runtime.getRuntime().exec("chmod 0666 " + fileName);
// 			success =  p.exitValue() == 0;
// 		} catch (IOException e) {
// 			e.printStackTrace();
// 		}
// 		return success;
// 	}
	
	public boolean chmod(String fileName) {
		UnixFile file = new UnixFile(fileName);
		return file.setMode(0600);
	}

	public static void printSystemInfo() {
		System.out.print( "\n\n");
		System.out.println( "*********************************************" );
		System.out.println( "* System Provider Test I                    *" );
		System.out.println( "*********************************************\n" );
	
		System.out.println( "getUid() = "+UnixSystem.getUid() );
		System.out.println( "getGid() = "+UnixSystem.getGid() );
		System.out.println( "getPid() = "+UnixSystem.getPid() );
		System.out.println( "getParentPid() = "+UnixSystem.getParentPid() );
		System.out.println( "getEffectiveUid() = "+UnixSystem.getEffectiveUid() );
		System.out.println( "getEffectiveGid() = "+UnixSystem.getEffectiveGid() );

		int umask = UnixSystem.getUmask((short)0);
		System.out.println( "getUmask(0) = 0"+Integer.toOctalString(umask) );

		try {
			System.out.println("\nUsing ``UnixSystem.setUid(0)'' to become root." );
			if ( System.getProperty("user.name").equals("root") )
			System.out.println("I am `root' so it should work WITHOUT exception." );
			else
			System.out.println("I am NOT currently `root' so it should fail WITH exception." );
			UnixSystem.setUid(0);
		}
		catch ( UnixSystemException use ) {
			System.err.println( "Exception:"+use.getMessage() );
		}
    }

}
