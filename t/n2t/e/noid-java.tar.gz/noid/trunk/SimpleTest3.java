import java.io.*;
import java.util.ArrayList;
import java.util.regex.*;
import junit.framework.*;

public class SimpleTest3 extends TestCase {

	public SimpleTest3(String name) {
		super(name);
	}
	
	protected void setUp() {
	}

	public void testFoo() {

		Minter minter = new Minter();

		File noidDir = new File("NOID");

		// XXX what if this is a regualr file?
		if (noidDir.isDirectory()) {
			Util.deleteDir(noidDir);
		}

		Util.doExec("./runNoid.sh dbcreate tst5.rde long 13030 cdlib.org noidTest >/dev/null");

		assertTrue("NOID was created failed", noidDir.isDirectory());

		if (!noidDir.isDirectory()) {
			System.err.println("something is seriously wrong, stopped");
			System.exit(1);
		}

		String[] files = { "README", "log", "logbdb", "noid.bdb" };
		for (int i = 0; i < files.length; i++) {
			File f = new File("NOID/" + files[i]);
			assertTrue("NOID/" + files[i] + " was not created", f.exists());
		}

		if (!(new File("NOID/noid.bdb")).exists()) {
			System.err.println("something is seriously wrong, stopped");
			System.exit(1);
		}

		ArrayList output = new ArrayList();

		// Mint all but the last two of 290.
		Util.doExec("./runNoid.sh mint 288", output);

		String line;
		Pattern patt = Pattern.compile("^\\s*id:\\s+");
		Matcher matcher = patt.matcher("");
		for (int i = 0; i < output.size(); i++) {
			line = (String) output.get(i);
			matcher.reset(line);
			line = matcher.replaceFirst("");
			output.set(i, line);
		}

		int len = output.size();

		if (len > 0 && Util.isEmpty((String) output.get(len - 1))) {
			output.remove(len - 1);
		}

		assertEquals("number of minted noids is 288", 288, output.size());

		String[] save_noid = new String[3];
		save_noid[0] = (String) output.get(20);
		save_noid[1] = (String) output.get(55);
		save_noid[2] = (String) output.get(155);

		// XXX start from here
		Util.doExec("./runNoid.sh mint 1");

		output.clear();
		Util.doExec("./runNoid.sh queue now " + save_noid[0] + " 2>&1", output);
		
		Util.doExec("./runNoid.sh hold release "
			+ save_noid[0] + " "
			+ save_noid[1] + " "
			+ save_noid[2] + " > /dev/null");

		Util.doExec("./runNoid.sh queue now "
			+ save_noid[0] + " "
			+ save_noid[1] + " "
			+ save_noid[2] + " > /dev/null");

		Util.doExec("./runNoid.sh mint 3", output);

		for (int i = 0; i < output.size(); i++) {
			line = (String) output.get(i);
			matcher.reset(line);
			line = matcher.replaceFirst("");
			output.set(i, line);
		}

		len = output.size();

		if (len > 0 && Util.isEmpty((String) output.get(len - 1))) {
			output.remove(len - 1);
		}

		assertEquals("(minted 3 queued noids) number of minted noids is 3", 3, output.size());

		assertEquals("first of three queued & reminted noids",
			(String) output.get(0), save_noid[0]);
		assertEquals("second of three queued & reminted noids",
			(String) output.get(1), save_noid[1]);
		assertEquals("third of three queued & reminted noids",
			(String) output.get(2), save_noid[2]);

		Util.doExec("./runNoid.sh mint 1", output);
		

		
	}

}
