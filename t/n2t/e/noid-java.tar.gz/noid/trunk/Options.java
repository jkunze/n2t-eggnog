
public interface Options {
	
	public void parseOptions();
	
	public boolean getDebug();
	
	public boolean getHelp();
	
	public boolean getVersion();
	
	public Integer getLocktest();
	
	public String getDbdir();

}
