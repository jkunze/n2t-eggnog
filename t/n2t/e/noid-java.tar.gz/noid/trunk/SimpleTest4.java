import java.io.*;
import java.util.ArrayList;
import java.util.regex.*;
import junit.framework.*;

public class SimpleTest4 extends TestCase {

	public SimpleTest4(String name) {
		super(name);
	}
	
	protected void setUp() {
	}

	public void testFoo() {

		Minter minter = new Minter();

		File noidDir = new File("NOID");

		// XXX what if this is a regualr file?
		if (noidDir.isDirectory()) {
			Util.deleteDir(noidDir);
		}

		Util.doExec("./runNoid.sh dbcreate tst5.rde long 13030 cdlib.org noidTest >/dev/null");

		assertTrue("NOID was created failed", noidDir.isDirectory());

		if (!noidDir.isDirectory()) {
			System.err.println("something is seriously wrong, stopped");
			System.exit(1);
		}

		String[] files = { "README", "log", "logbdb", "noid.bdb" };
		for (int i = 0; i < files.length; i++) {
			File f = new File("NOID/" + files[i]);
			assertTrue("NOID/" + files[i] + " was not created", f.exists());
		}

		if (!(new File("NOID/noid.bdb")).exists()) {
			System.err.println("something is seriously wrong, stopped");
			System.exit(1);
		}

		ArrayList output = new ArrayList();

		// Mint all but the last two of 290.
		Util.doExec("$noid_cmd queue now 13030/tst27h >/dev/null", output);


		output.clear();

		try {
			BufferedReader in = new BufferedReader(new FileReader("NOID/log"));

			assertTrue("", true);
		
			String str;
			while ((str = in.readLine()) != null) {
				output.add(str);
			}
			in.close();
			
		
		} catch (IOException e) {
		}

		assertEquals("number of lines in NOID/log", 4, output.size());


		if (output.size() != 4) {
			System.err.println("log_lines");
			System.exit(1);
		}
		
	}

}
