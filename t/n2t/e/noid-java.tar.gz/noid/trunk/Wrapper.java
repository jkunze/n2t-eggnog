import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import jargs.gnu.CmdLineParser;
import javaunix.*;
import com.sleepycat.db.DatabaseConfig;

public class Wrapper {

	private String dbdir;
	private String contact;
	private String dbName;
	private HashMap validMap;

	private static final String[] validCommands = {
		"bind", "dbinfo", "dbcreate", "fetch",
		"get", "hello", "help", "hold", "mint",
		"note", "peppermint", "queue", "validate"
	};
	
	private static String[] validHelpTopics;

	private Minter minter;
	
	public void Wrapper() {
		minter = new Minter(contact, "foo");
	}
	
	static void init() {
		validMap = new HashMap();
		int len = validCommands.length;
		for (int i = 0; i < len; i++) {
			validMap.put(validCommands[i], "1");
		}
	}

	static boolean usage(boolean in_error, boolean brief, String topic) {
		PrintStream out = in_error ? System.err : System.out;
		if (topic == null)
			topic = "intro";
		topic = topic.toLowerCase();
		
		HashMap info = null;
		
		if (true)
			info = initHelp();

		int k;

		ArrayList blurbs = new ArrayList();
		for (k = 0; k < validHelpTopics.length; k++) {
			if (validHelpTopics[k].startsWith(topic))
				blurbs.add(validHelpTopics[k]);
		}

		if (blurbs.size() != 1) {
			out.print(
				(blurbs.size() < 1
					? "Sorry: nothing under \"" + topic + "\".\n"
					: "Help: Your request ($topic), matches more than one "
						+ "topic:\n\t(" + blurbs.toString() + ").\n")
				+ " You might try one of these topics:");

			ArrayList topics = new ArrayList();
			for (k = 0; k < validHelpTopics.length; k++)
				topics.add(validHelpTopics[k]);
			int n = 0;
			int topics_per_line = 8;
			while (true) {
				if (topics.size() == 0) {
					System.out.println();
					break;
				} else if (n++ % topics_per_line == 0) {
					System.out.print("\n\t");
				} else {
					System.out.print(" " + (String)topics.remove(0));
				}
			}
			System.out.print("\n\n");
			return true;
		}
	
		// If we get here, @blurbs names one story.
		String blurb = (String)blurbs.remove(0);
	
		// Big if-elsif clause to switch on requested topic.
		//
		// Note that we try to make the output conform to ANVL syntax;
		// in the case of help output, every line tries to be a continuation
		// line for the value of an element called "Usage".  To do this we
		// pass all output through a routine that just adds a space after
		// every newline.  The end of the output should end the ANVL record,
		// so we print "\n\n" at the end.
		//
		String t;
		String i;
		if (blurb.equals("intro")) {
			bprint(out, "\n"
				+ "Usage:\n"
				+ "              noid [-f Dbdir] [-v] [-h] Command Arguments"
				+ (brief
					? "\n"
						+ "              noid -h             (for "
						+ "help with a Command summary)."
					: "\n\n"
						+ "\n"
						+ "Dbdir defaults to \".\" if not "
						+ "found from -f or a NOID environment variable.\n"
						+ "For more information try \"perldoc noid\" "
						+ "or \"noid help Command\".  Summary:\n"));
	
			if (brief) {
				System.out.print("\n\n");
				return true;
			}
	
			for (k = 0; k < validCommands.length; k++) {
				t = validCommands[k];
				i = (String)info.get(t + "/brief");
				if (i == null || i.length() == 0)
					continue;
				bprint(out, i);
			}
	
				
			bprint(out, "\n"
				+ "If invoked as \"noidu...\", output is formatted for a web client.  Give Command\n"
				+ "as \"-\" to run a block of noid Commands read from stdin or from POST data.@;\n");
			System.out.print("\n\n");
			return true;
		}
		
		if (brief)
			blurb += "/brief";
		t = (String)info.get(blurb);
		
		if (t == null || t.length() == 0) {
			out.print("Sorry: no information on \"" + blurb + "\".\n\n");
			return true;
		}
		bprint(out, t);
		System.out.println();
	
		// yyy fix these verbose messages
	
		String yyyy = "\n"
			+ "Called as \"noid\", an id generator accompanies every COMMAND.  Called as\n"
			+ "\"noi\", the id generator is supplied implicitly by looking first for a\n"
			+ "NOID environment variable and, failing that, for a file calld \".noid\" in\n"
			+ "the current directory.  Examples show the explicit form.  To create a\n"
			+ "generator, use\n"
			+ "\n"
			+ "	noid ck8 dbcreate TPL SNAA\n"
			+ "\n"
			+ "where you replace TPL with a template that defines the shape and number\n"
			+ "of all identifiers to be minted by this generator.  You replace SNAA with\n"
			+ "the name (eg, the initials) of the sub NAA (Name Assigning Authority) that\n"
			+ "will be responsible for this generator; for example, if the Online Archive\n"
			+ "of California is the sub-authority for a template, SNAA could be \"oac\".\n"
			+ "This example of generator intialization,\n"
			+ "\n"
			+ "	noid oac.noid dbcreate pd2.wwdwwdc oac\n"
			+ "\n"
			+ "sets up the \"oac.noid\" identifier generator.  It can create \"nice opaque\n"
			+ "identifiers\", such as \"pd2pq5dk9z\", suitable for use as persistent\n"
			+ "identifiers should the supporting organization wish to provide such a\n"
			+ "level of commitment.  This generator is also capable of holding a simple\n"
			+ "sequential counter (starting with 1), which some callers may wish to use\n"
			+ "as an internal number to keep track of minted external identifiers.\n"
			+ "[ currently accessible only via the count() routine ]\n"
			+ "\n"
			+ "In the example template, \"pd2\" is a constant prefix for an identifier\n"
			+ "generator capable of producing 70,728,100 identifiers before it runs out.\n"
			+ "A template has the form \"prefix.mask\", where 'prefix' is a literal string\n"
			+ "prepended to each identifier and 'mask' specifies the form of the generated\n"
			+ "identifier that will appear after the prefix (but with no '.' between).\n"
			+ "Mask characters are 'd' (decimal digit), 'w' (limited alpha-numeric\n"
			+ "digit), 'c' (a generated check character that may only appear in the\n"
			+ "terminal position).\n"
			+ "\n"
			+ "Alternatively, if the mask contains an 's' (and no other letters), dbcreate\n"
			+ "initializes a generator of sequential numbers.  Instead of seemingly random\n"
			+ "creates sequentially generated number.  Use '0s'\n"
			+ "to indicate a constant width number padded on the left with zeroes.\n";
		return true;
	}


	static HashMap initHelp() {

		// For convenient maintenance, we store individual topics in separate
		// array elements.  So as not to slow down script start up, we don't
		// pre-load anything.  In this way only the requester of help info,
		// who does not need speed for this purpose, pays for it.
		//
		String[] foo = { "intro", "all", "template" };
		validHelpTopics = new String[validCommands.length + 3];
		System.arraycopy(foo, 0, validHelpTopics, 0, foo.length);
		System.arraycopy(validCommands, 0, validHelpTopics, foo.length, validCommands.length);
	
		HashMap info = new HashMap();
	
		info.put("bind/brief", "\n"
			+ "   noid bind How Id Element Value	# to bind an Id's Element, where\n"
			+ "      How is set|add|insert|new|replace|mint|append|prepend|delete|purge.\n"
			+ "      Use an Id of :idmap/Idpattern, Value=PerlReplacementPattern so that\n"
			+ "      fetch returns variable values.  Use \":\" as Element to read Elements\n"
			+ "      and Values up to a blank line from stdin (up to EOF with \":-\").\n");
		info.put("bind", "");
		info.put("dbinfo/brief", "");
		info.put("dbinfo", "");
		info.put("dbcreate/brief", "\n"
			+ "   noid dbcreate [ Template (long|-|short) [ NAAN NAA SubNAA ] ]\n"
			+ "      where Template=prefix.Tmask, T=(r|s|z), and mask=string of (e|d|k)\n");
		info.put("dbcreate", "\n"
			+ "To create an identifier minter governed by Template and Term (\"long\" or \"-\"),\n"
			+ "\n"
			+ "   noid dbcreate [ Template Term [ NAAN NAA SubNAA ] ]\n"
			+ "\n"
			+ "The Template gives the number and form of generated identifiers.  Examples:\n"
			+ "\n"
			+ "    .rddd        minter of random 3-digit numbers that stops after the 1000th\n"
			+ "    .zd          sequential numbers without limit, adding new digits as needed\n"
			+ "  bc.sdddd       sequential 4-digit numbers with constant prefix \"bc\"\n"
			+ "    .rdedeede    .7 billion random ids, extended-digits at chars 2, 4, 5 and 7\n"
			+ "  fk.rdeeek      .24 million random ids with prefix \"fk\" and final check char\n"
			+ "\n"
			+ "For persistent identifiers, use \"long\" for Term, and specify the NAAN, NAA,\n"
			+ "and SubNAA.  Otherwise, use \"-\" for Term or omit it.  The NAAN is a globally\n"
			+ "registered Name Assigning Authority Number; for identifiers conforming to the\n"
			+ "ARK scheme, this is a 5-digit number registered with ark@cdlib.org, or 00000.\n"
			+ "The NAA is the character string equivalent registered for the NAAN; for\n"
			+ "example, the NAAN, 13030, corresponds to the NAA, \"cdlib.org\".  The SubNAA\n"
			+ "is also a character string, but it is a locally determined and possibly\n"
			+ "structured subauthority string (e.g., \"oac\", \"ucb/dpg\", \"practice_area\") that\n"
			+ "is not globablly registered.\n");
		info.put("fetch/brief", "\n"
			+ "   noid fetch Id Element ...		# fetch/map one or more Elements\n");
		info.put("fetch", "\n"
			+ "To bind,\n"
			+ "\n"
			+ "   noid bind replace fk0wqkb myGoto http://www.cdlib.org/foobar.html\n"
			+ "\n"
			+ "sets \"myGoto\" element of identifier \"fk0wqkb\" to a string (here a URL).\n");
		info.put("get/brief", "\n"
			+ "   noid get Id Element ...		# fetch/map Elements without labels\n");
		info.put("get", "");
		info.put("hello/brief", "");
		info.put("hello", "");
		info.put("hold/brief", "\n"
			+ "   noid hold (set|release) Id ...	# place or remove a \"hold\" on Id(s)\n");
		info.put("hold", "");
		info.put("mint/brief", "\n"
			+ "   noid mint N [ Elem Value ]	# to mint N identifiers (optionally binding)\n");
		info.put("mint", "");
		info.put("note/brief", "");
		info.put("note", "");
		info.put("peppermint/brief", "");
		info.put("peppermint", "");
		info.put("queue/brief", "\n"
			+ "   noid queue (now|first|lvf|Time) Id ...	# queue (eg, recycle) Id(s)\n"
			+ "      Time is NU, meaning N units, where U= d(ays) | s(econds).\n"
			+ "      With \"lvf\" (Lowest Value First) lowest value of id will mint first.\n");
		info.put("queue", "");
		info.put("validate/brief", "\n"
			+ "   noid validate Template Id ...	# to check if Ids are valid\n"
			+ "      Use Template of \"-\" to use the minter's native template.\n");
		info.put("validate", "");
		
		return info;
	}

	static String whoAreYou(boolean isWeb) {
	
		String contact = null;

// 		if (isWeb) {
// 			user = System.getenv("REMOTE_USER");
// 			host = System.getenv("REMOTE_HOST");
// 			if (host == null)
// 				host = System.getenv("REMOTE_ADDR");
// 			user += '@' + host;
// 		}
		
		try {
		
			int uid = UnixSystem.getUid();
			int gid = UnixSystem.getGid();
			int effectiveUid = UnixSystem.getEffectiveUid();
			int effectiveGid = UnixSystem.getEffectiveGid();
	
			Password passwd = UnixSystem.getPasswordByUid(uid);
			Group group = UnixSystem.getGroupByGid(gid);
		
			String userName = System.getProperty("user.name");
			if (userName == null)
				userName = passwd.getName();
			if (userName == null)
				return "";
		
// 			System.err.println("username = " + userName);
	
			String groupName = group.getName();
	
			contact = userName + "/" + valueOrEmpty(groupName);
	
			if (uid != effectiveUid) {
				passwd = UnixSystem.getPasswordByUid(uid);
				group = UnixSystem.getGroupByGid(gid);
				userName = passwd.getName();
				if (userName == null)
					return "";
				groupName = group.getName();
				contact += " (" + userName + "/"
					+ valueOrEmpty(groupName) + ")";
			}

		} catch (Exception e) {
			// handle exception
			System.err.println(e);
		}

		return contact;
	
	}

	static String valueOrEmpty(String s) {
		return s != null ? s : "";
	}
	
    public static void testProcessIDAccess() 
    {
		System.out.print( "\n\n");
		System.out.println( "*********************************************" );
		System.out.println( "* System Provider Test I                    *" );
		System.out.println( "*********************************************\n" );
	
		System.out.println( "getUid() = "+UnixSystem.getUid() );
		System.out.println( "getGid() = "+UnixSystem.getGid() );
		System.out.println( "getPid() = "+UnixSystem.getPid() );
		System.out.println( "getParentPid() = "+UnixSystem.getParentPid() );
		System.out.println( "getEffectiveUid() = "+UnixSystem.getEffectiveUid() );
		System.out.println( "getEffectiveGid() = "+UnixSystem.getEffectiveGid() );
	
		int umask = UnixSystem.getUmask((short)0);
		System.out.println( "getUmask(0) = 0"+Integer.toOctalString(umask) );
	
		try {
			System.out.println("\nUsing ``UnixSystem.setUid(0)'' to become root." );
			if ( System.getProperty("user.name").equals("root") )
			System.out.println("I am `root' so it should work WITHOUT exception." );
			else
			System.out.println("I am NOT currently `root' so it should fail WITH exception." );
			UnixSystem.setUid(0);
		}
		catch ( UnixSystemException use ) {
			System.err.println( "Exception:"+use.getMessage() );
		}
    }


	// This routine may not make sense in the URL interface.
	//
	static boolean dbcreate (Minter minter, String templ,
			String policy,
			String naan,
			String naa,
			String subnaa) {

		String dbReport = minter.dbCreate(dbdirValue, contact,
			templ, policy, naan, naa, subnaa);
				
		if (dbReport == null) {
			System.out.print(minter.getMsg());
			return false;
		}
		System.out.println(dbReport);
		return true;
	}

	static boolean dbinfo (Minter minter, String level) {
	
		if (level == null) {
			level = "brief";
		}

		DatabaseConfig config = new DatabaseConfig();
		config.setReadOnly(true);

		Noid noid = minter.dbOpen(dbName, config);

		if (noid == null) {
			System.err.println(noid.getMsg());
			return false;
		}

		minter.dbInfo(noid, level);
		minter.dbClose(noid);
		
		return true;
	}
	
	static boolean fetch (Minter minter, String id, String[] elems) {
		return getfetch(minter, true, id, elems);
	}
	
	static boolean get (Minter minter, String id, String[] elems) {
		return getfetch(minter, false, id, elems);
	}
	
	static boolean getfetch (Minter minter,
			boolean verbose, String id, String[] elems) {

		DatabaseConfig config = new DatabaseConfig();
		config.setReadOnly(true);

		Noid noid = minter.dbOpen(dbName, config);

		if (noid == null) {
			System.err.println(noid.getMsg());
			return false;
		}

		String fetched = minter.fetch(noid, verbose, id, elems);
		if (fetched == null) {
			System.err.println(minter.getMsg(noid));
		} else {
			System.out.print(fetched);
			if (verbose) {
				System.out.println();
			}
		}
		minter.dbClose(noid);
		return true;
	}
	
	static void hello() {
		System.out.println("Hello.");
	}
	
	static boolean help (String topic) {
		boolean in_error = false;
		boolean brief = false;
		return usage(in_error, brief, topic);
	}

	
	// yyy what about a "winnow" routine that is either started
	//     from cron or is started when an exiting noid call notices
	//     that there's some harvesting/garbage collecting to do and
	//     schedules it for, say, 10 minutes hence (by not exiting,
	//     but sleeping for 10 minutes and then harvesting)?
	
	static boolean hold (Minter minter, String on_off, String[] ids) {
	
		Noid noid = minter.dbOpen(dbName, null);
		if (noid == null) {
			System.err.println(noid.getMsg());
			return false;
		}
		
		if (minter.hold(noid, contact, on_off, ids) == 0) {
			System.err.print(minter.getMsg(noid));
			usage(true, true, "hold");
			minter.dbClose(noid);
			return false;
		}
		
		System.out.println(minter.getMsg(noid));	// no error message at all
		minter.dbClose(noid);
		return true;
	}

	static boolean peppermint (Minter minter, String n,
			String elem, String value) {
		return mint(minter, n, elem, value, true);
	}

	static boolean mint (Minter minter, String num, String elem,
			String value, boolean pepper) {
	
		if (pepper) {
			System.err.println(
				"The peppermint command is not implemented yet.");
			return false;
		}


		if (num == null || !num.matches("^\\d+$")) {
			System.err.println("Argument error: expected "
				+ "positive integer, got "
				+ (num != null ? "\"" + num + "\"" : "nothing"));
			usage(true, true, "mint");
			return false;
		}
		
		int n = Integer.parseInt(num);
		
		Noid noid = minter.dbOpen(dbName, null);
		if (noid == null) {
			System.err.println(noid.getMsg());
			return false;
		}
	
		String id;
		while (n-- > 0) {
			id = minter.mint(noid, contact, pepper);
			if (id == null) {
				System.err.print(minter.getMsg(noid));
				minter.dbClose(noid);
				return false;
			}
			System.out.println("id: " + id);
		}
		
		minter.dbClose(noid);
		System.out.println();
		return true;
	}
	
	public static boolean note (Minter minter, String key, String value) {

		if (key == null || value == null) {
			System.err.println("You must supply a key and a value.");
			usage(true, true, "note");
			return false;
		}

		Noid noid = minter.dbOpen(dbName, null);

		if (!minter.note(noid, contact, key, value))
			System.out.println(noid.getMsg());

		noid.close();
		return true;
	}

	public static boolean queue (Minter minter, String when, String[] ids) {
	
		Noid noid = minter.dbOpen(dbName, null);

		if (noid == null) {
			System.err.println(noid.getMsg());
			return false;
			// throw new Exception(noid.getMsg();
		}

		String[] queued = minter.queue(noid, contact, when, ids);

		boolean retval;
		
		if (queued.length == 0) {
			retval = false;
			System.err.println(noid.getMsg());
		} else {
			retval = true;
			System.out.println(join("\n", queued));
		}

		int n = 0;
		for (int i = 0; i < queued.length; i++) {
			if (!queued[i].startsWith("error:")) {
				n++;
			}
		}
		
		System.out.println("note: " + n + " identifier"
			+ (n == 1 ? "" : "s") + " queued");
		noid.close();
		return retval;
	}
	
	// Returns the number of valid ids.
	static int validate (Minter minter, String templ, String[] ids) {
	
		DatabaseConfig config = new DatabaseConfig();
		config.setReadOnly(true);

		Noid noid = minter.dbOpen(dbName, config);

		if (noid == null) {
			System.err.println(noid.getMsg());
			return 0;
		}

		String[] valids = minter.validate(noid, templ, ids);
		if (valids.length == 0) {
			System.err.println(noid.getMsg());
			noid.close();
			usage(true, true, "validate");
			return 0;
		}

		int numErrs = 0;
		for (int i = 0; i < valids.length; i++) {
			System.out.println(valids[i]);
			if (valids[i].startsWith("error:")) {
				numErrs++;
			}
		}

		noid.close();
		return ids.length - numErrs;
	}

}
	
// vim: set ts=4 nohls:
